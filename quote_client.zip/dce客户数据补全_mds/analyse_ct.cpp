#include <stdio.h>
#include <time.h>

#define BUFF_SIZE 4096

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long ULONG;
typedef long LONG;
typedef char INT1;
typedef short INT2;
typedef int INT4;
typedef unsigned int UINT4;
typedef float REAL4;
typedef double REAL8;
typedef int BOOL;
typedef unsigned long long UINT8;

enum EDataType
{
	eMDSBest = 0,
	eMDSDeep,
    eMDSArbiBest,
    eMDSOptParam,
	eMDSTenEntrust,
	eMDSOrderStatistic,
	eMDSMarchPriceQty,
};

#pragma pack(1)
struct PubMDData
{
    INT1 Type;          //行情域标识
    UINT4 Length;       //报文长度
    UINT4 Version;      //版本从1开始
    UINT4 MDGNo;        //交易所行情组编号
    UINT8 SeqNo;        //交易所行情组内报文编号
    INT1 Exchange[8];   //交易所
    INT1 Contract[129]; //合约代码
    INT1 TradeDate[9]; //行情日期 YYYYMMDD
    INT1 GenTime[13];  //生成时间 HH:MM:SS.sss
    UINT4 ChannelNo;   //通道编号 (组播使用)
    UINT4 PackageNo;   //本通道的报文编号
};
////////////////////////////////////////////////
///最优
////////////////////////////////////////////////
struct MDBest:public PubMDData
{
    REAL8 LastPrice;        //最新价
    UINT4 LastMatchQty;     //最新成交量
    UINT4 MatchTotQty;      //成交数量
    REAL8 Turnover;         //成交金额
    UINT4 LastOpenInterest; //昨持仓量
    UINT4 OpenInterest;     //持仓量
    INT4 InterestChg;       //持仓量变化
    REAL8 BuyPriceOne;      //买入价格1
    UINT4 BuyQtyOne;        //买入数量1
    UINT4 BuyImplyQtyOne;   //买1推导量
    REAL8 SellPriceOne;     //卖出价格1
    UINT4 SellQtyOne;       //卖出数量1
    UINT4 SellImplyQtyOne;  //卖1推导量
    REAL8 AvgPrice;         //成交均价
    REAL8 OpenPrice;        //今开盘
    REAL8 Close;            //今收盘
    REAL8 ClearPrice;       //今结算价
    REAL8 HighPrice;        //最高价
    REAL8 LowPrice;         //最低价
    REAL8 LifeLow;          //历史最低价
    REAL8 LifeHigh;         //历史最高价
    REAL8 RiseLimit;        //最高报价
    REAL8 FallLimit;        //最低报价
    REAL8 LastClearPrice;   //昨结算价
    REAL8 LastClose;        //昨收盘
};
//深度行情
struct MDDeep:public PubMDData
{
    REAL8 BuyPriceOne;      //买入价格1
    UINT4 BuyQtyOne;        //买入数量1
    UINT4 BuyImplyQtyOne;   //买1推导量
    REAL8 BuyPriceTwo;      //买入价格2
    UINT4 BuyQtyTwo;        //买入数量2
    UINT4 BuyImplyQtyTwo;   //买2推导量
    REAL8 BuyPriceThree;    //买入价格3
    UINT4 BuyQtyThree;      //买入数量3
    UINT4 BuyImplyQtyThree; //买3推导量
    REAL8 BuyPriceFour;     //买入价格4
    UINT4 BuyQtyFour;       //买入数量4
    UINT4 BuyImplyQtyFour;  //买4推导量
    REAL8 BuyPriceFive;     //买入价格5
    UINT4 BuyQtyFive;       //买入数量5
    UINT4 BuyImplyQtyFive;  //买5推导量
    REAL8 SellPriceOne;      //卖出价格1
    UINT4 SellQtyOne;        //卖出数量1
    UINT4 SellImplyQtyOne;   //卖1推导量
    REAL8 SellPriceTwo;      //卖出价格2
    UINT4 SellQtyTwo;        //卖出数量2
    UINT4 SellImplyQtyTwo;   //卖2推导量
    REAL8 SellPriceThree;    //卖出价格3
    UINT4 SellQtyThree;      //卖出数量3
    UINT4 SellImplyQtyThree; //卖3推导量
    REAL8 SellPriceFour;     //卖出价格4
    UINT4 SellQtyFour;       //卖出数量4
    UINT4 SellImplyQtyFour;  //卖4推导量
    REAL8 SellPriceFive;     //卖出价格5
    UINT4 SellQtyFive;       //卖出数量5
    UINT4 SellImplyQtyFive;  //卖5推导量
};

////////////////////////////////////////////////
///MDOrderStatistic：加权平均以及委托总量行情
////////////////////////////////////////////////
struct MDOrderStatistic:public PubMDData
{
    UINT4 TotalBuyOrderNum;              //买委托总量
    UINT4 TotalSellOrderNum;             //卖委托总量
    REAL8 WeightedAverageBuyOrderPrice;  //加权平均委买价格
    REAL8 WeightedAverageSellOrderPrice; //加权平均委卖价格
}ORDERSTATISTIC;
#pragma pack()

int main() 
{
	FILE * fp = fopen("quoteRecord/20191218.bin", "rb");

	int n = 1;
	while (n > 0) {
		struct timespec timespecBuf;
		n = fread(&timespecBuf, sizeof(struct timespec), 1, fp);
		printf("timespec sizeof: %d, %ld.%ld\n", sizeof(struct timespec), timespecBuf.tv_sec, timespecBuf.tv_nsec);

		EDataType quote_style;
		fread(&quote_style, sizeof(EDataType), 1, fp);
		printf("EDataType sizeof: %d, %d\n", sizeof(EDataType), quote_style);

		switch (quote_style) {
		case eMDSBest:
			struct MDBest mdBest;
			fread(&mdBest, sizeof(struct MDBest), 1, fp);
			printf("MDBest sizeof: %d\n", sizeof(struct MDBest));
			break;
		case eMDSDeep:
			struct MDDeep mdDeep;
			fread(&mdDeep, sizeof(struct MDDeep), 1, fp);
			printf("MDDeep sizeof: %d\n", sizeof(struct MDDeep));
            break;
		case eMDSOrderStatistic:
			struct MDOrderStatistic orderStatistic;
			fread(&orderStatistic, sizeof(struct MDOrderStatistic), 1, fp);
			printf("MDOrderStatistic sizeof: %d\n", sizeof(struct MDOrderStatistic));
			break;
		default:
			printf("default, quote_style: %d\n", quote_style);
		}
	}

	fclose(fp);
	return 0;
}
