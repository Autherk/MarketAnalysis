#include <stdio.h>
#include <time.h>
#include <float.h>
#include "UstpApiStruct.h"

#define BUFF_SIZE 4096

enum EDataType
{
	eDepthMarketData = 0,
};

double DoubleFormat(double val)
{
	if (val == DBL_MAX) return float(0);
	else return val;
}

int main() 
{
	FILE * fp = fopen("quoteRecord/20190902.bin", "rb");

	int n = 1;
	while (n > 0) {
		struct timespec timespecBuf;
		n = fread(&timespecBuf, sizeof(struct timespec), 1, fp);
		printf("timespec sizeof: %d, %ld.%ld\n", sizeof(struct timespec), timespecBuf.tv_sec, timespecBuf.tv_nsec);

		EDataType quote_style;
		fread(&quote_style, sizeof(EDataType), 1, fp);
		printf("EDataType sizeof: %d, %d\n", sizeof(EDataType), quote_style);

		switch (quote_style) {
		case eDepthMarketData:
			struct CUstpFtdcDepthMarketDataField depthMarketData;
			fread(&depthMarketData, sizeof(struct CUstpFtdcDepthMarketDataField), 1, fp);
			printf("CUstpFtdcDepthMarketDataField sizeof: %d, \
TradingDay: %s, SettlementGroupID: %s, SettlementID: %d, PreSettlementPrice: %5f, PreClosePrice: %5f, \
PreOpenInterest: %5f, PreDelta: %5f, OpenPrice: %5f, HighestPrice: %5f, LowestPrice: %5f, ClosePrice: %5f, \
UpperLimitPrice: %5f, LowerLimitPrice: %5f, SettlementPrice: %5f, CurrDelta: %5f, LastPrice: %5f, Volume: %d, \
Turnover: %5f, OpenInterest: %5f, BidPrice1: %5f, BidVolume1: %d, AskPrice1: %5f, AskVolume1: %d, \
BidPrice2: %5f, BidVolume2: %d, BidPrice3: %5f, BidVolume3: %d, \
AskPrice2: %5f, AskVolume2: %d, AskPrice3: %5f, AskVolume3: %d, \
BidPrice4: %5f, BidVolume4: %d, BidPrice5: %5f, BidVolume5: %d, \
AskPrice4: %5f, AskVolume4: %d, AskPrice5: %5f, AskVolume5: %d, \
InstrumentID: %s, UpdateTime: %s, UpdateMillisec: %d\n",
				sizeof(struct CUstpFtdcDepthMarketDataField), depthMarketData.TradingDay,
				depthMarketData.SettlementGroupID, depthMarketData.SettlementID, DoubleFormat(depthMarketData.PreSettlementPrice),
				DoubleFormat(depthMarketData.PreClosePrice), DoubleFormat(depthMarketData.PreOpenInterest), 
				DoubleFormat(depthMarketData.PreDelta), DoubleFormat(depthMarketData.OpenPrice), 
				DoubleFormat(depthMarketData.HighestPrice), DoubleFormat(depthMarketData.LowestPrice),
				DoubleFormat(depthMarketData.ClosePrice), DoubleFormat(depthMarketData.UpperLimitPrice), 
				DoubleFormat(depthMarketData.LowerLimitPrice), DoubleFormat(depthMarketData.SettlementPrice), 
				DoubleFormat(depthMarketData.CurrDelta), DoubleFormat(depthMarketData.LastPrice),
				depthMarketData.Volume, DoubleFormat(depthMarketData.Turnover), DoubleFormat(depthMarketData.OpenInterest),
				DoubleFormat(depthMarketData.BidPrice1), depthMarketData.BidVolume1, 
				DoubleFormat(depthMarketData.AskPrice1), depthMarketData.AskVolume1, 
				DoubleFormat(depthMarketData.BidPrice2), depthMarketData.BidVolume2,
				DoubleFormat(depthMarketData.BidPrice3), depthMarketData.BidVolume3, 
				DoubleFormat(depthMarketData.AskPrice2), depthMarketData.AskVolume2, 
				DoubleFormat(depthMarketData.AskPrice3), depthMarketData.AskVolume3,
				DoubleFormat(depthMarketData.BidPrice4), depthMarketData.BidVolume4, 
				DoubleFormat(depthMarketData.BidPrice5), depthMarketData.BidVolume5, 
				DoubleFormat(depthMarketData.AskPrice4), depthMarketData.AskVolume4,
				DoubleFormat(depthMarketData.AskPrice5), depthMarketData.AskVolume5, 
				depthMarketData.InstrumentID, depthMarketData.UpdateTime, depthMarketData.UpdateMillisec);	
			break;
		default:
			printf("default, quote_style: %d\n", quote_style);
		}
	}

	fclose(fp);
	return 0;
}


