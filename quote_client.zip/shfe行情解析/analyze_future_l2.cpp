#include <stdio.h>
#include "main.h"

#define BUFF_SIZE 4096

enum EDataType
{
	dt_fut_lev2 = 0,
};

int main() 
{
	FILE * fp = fopen("quoteRecord/inefl2_20221109.bin", "rb");

	int n = 1;
	while (n > 0) {
		struct efh32_future_level2 quote;
		n = fread(&quote, sizeof(struct efh32_future_level2), 1, fp);
		printf("m_sequence: %d, ", quote.m_sequence);
		printf("m_exchange_id: %d, ", quote.m_exchange_id);
		printf("m_channel_id: %d, ", quote.m_channel_id);
		printf("m_symbol: %s, ", quote.m_symbol);
		printf("m_update_time_h: %d, ", quote.m_update_time_h);
		printf("m_update_time_m: %d, ", quote.m_update_time_m);
		printf("m_update_time_s: %d, ", quote.m_update_time_s);
		printf("m_millisecond: %d, ", quote.m_millisecond);
		printf("m_last_px: %.4f, ", quote.m_last_px);
		printf("m_last_share: %d, ", quote.m_last_share);
		printf("m_turnover: %.4f, ", quote.m_total_value);
		printf("m_open_interest: %.4f, ", quote.m_total_pos);

		printf("m_bid_1_px: %.4f, ", quote.m_bid1_px);
		printf("m_bid_1_share: %d, ", quote.m_bid1_share);
		printf("m_ask_1_px: %.4f, ", quote.m_ask1_px);
		printf("m_ask_1_share: %d, ", quote.m_ask1_share);

		printf("m_bid_2_px: %.4f, ", quote.m_bid2_px);
		printf("m_bid_2_share: %d, ", quote.m_bid2_share);
		printf("m_ask_2_px: %.4f, ", quote.m_ask2_px);
		printf("m_ask_2_share: %d, ", quote.m_ask2_share);

		printf("m_bid_3_px: %.4f, ", quote.m_bid3_px);
		printf("m_bid_3_share: %d, ", quote.m_bid3_share);
		printf("m_ask_3_px: %.4f, ", quote.m_ask3_px);
		printf("m_ask_3_share: %d, ", quote.m_ask3_share);

		printf("m_bid_4_px: %.4f, ", quote.m_bid4_px);
		printf("m_bid_4_share: %d, ", quote.m_bid4_share);
		printf("m_ask_4_px: %.4f, ", quote.m_ask4_px);
		printf("m_ask_4_share: %d, ", quote.m_ask4_share);

		printf("m_bid_5_px: %.4f, ", quote.m_bid5_px);
		printf("m_bid_5_share: %d, ", quote.m_bid5_share);
		printf("m_ask_5_px: %.4f, ", quote.m_ask5_px);
		printf("m_ask_5_share: %d, ", quote.m_ask5_share);
		printf("recv: %d\n\n", n);
	}

	fclose(fp);
	return 0;
}


