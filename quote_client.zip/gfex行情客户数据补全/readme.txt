补齐缺失数据：
1、解压.tar.gz文件
2、根据解压后的文件路径，修改analyze.cpp中的文件名，编译analyze.cpp
3、运行2中的可执行文件，结果无异常
4、根据功能需要修改analyze.cpp程序，获取其他行情字段
