#include <stdio.h>
#include <time.h>
#include <float.h>

#include "GFEXL2ApiDataType.h"
// #define BUFF_SIZE 4096

using namespace GFEX_L2;

enum EDataType
{
	eBestAndDeep = 0,
	eArbi,
	eMDTenEntrust,
	eMDRealTimePrice,
	eMDOrderStatistic,
	eMDMarchPriceQty,
};

double DoubleFormat(double val)
{
	if (val == DBL_MAX) return float(0);
	else return val;
}

int main(int argc, char *argv[]) 
{
	FILE * fp = fopen(argv[1], "rb");

	int n = 1;
	while (n > 0) {
		struct timespec timespecBuf;
		n = fread(&timespecBuf, sizeof(struct timespec), 1, fp);
        if (n > 0) {
            //printf("timespec sizeof: %d, %ld.%ld\n", sizeof(struct timespec), timespecBuf.tv_sec, timespecBuf.tv_nsec);

            EDataType quote_style;
            fread(&quote_style, sizeof(EDataType), 1, fp);
            //printf("EDataType sizeof: %d, %d\n", sizeof(EDataType), quote_style);

            switch (quote_style) {
            case eBestAndDeep:
                struct MDBestAndDeep bestAndDeep;
                fread(&bestAndDeep, sizeof(struct MDBestAndDeep), 1, fp);
                printf("MDBestAndDeep sizeof: %d, ", sizeof(struct MDBestAndDeep));
                printf("Type: %c, ", bestAndDeep.Type);
                printf("Length: %u, ", bestAndDeep.Length);
                printf("Version: %u, ", bestAndDeep.Version);
                printf("Time: %u, ", bestAndDeep.Time);
                printf("Exchange: %s, ", bestAndDeep.Exchange);
                printf("Contract: %s, ", bestAndDeep.Contract);
                printf("SuspensionSign: %d, ", bestAndDeep.SuspensionSign);
                printf("LastClearPrice: %.2f, ", DoubleFormat(bestAndDeep.LastClearPrice));
                printf("ClearPrice: %.2f, ", DoubleFormat(bestAndDeep.ClearPrice));
                printf("AvgPrice: %.2f, ", DoubleFormat(bestAndDeep.AvgPrice));
                printf("LastClose: %.2f, ", DoubleFormat(bestAndDeep.LastClose));
                printf("Close: %.2f, ", DoubleFormat(bestAndDeep.Close));
                printf("OpenPrice: %.2f, ", DoubleFormat(bestAndDeep.OpenPrice));
                printf("LastOpenInterest: %u, ", bestAndDeep.LastOpenInterest);
                printf("OpenInterest: %u, ", bestAndDeep.OpenInterest);
                printf("LastPrice: %.2f, ", DoubleFormat(bestAndDeep.LastPrice));
                printf("MatchTotQty: %u, ", bestAndDeep.MatchTotQty);
                printf("Turnover: %.2f, ", DoubleFormat(bestAndDeep.Turnover));
                printf("RiseLimit: %.2f, ", DoubleFormat(bestAndDeep.RiseLimit));
                printf("FallLimit: %.2f, ", DoubleFormat(bestAndDeep.FallLimit));
                printf("HighPrice: %.2f, ", DoubleFormat(bestAndDeep.HighPrice));
                printf("LowPrice: %.2f, ", DoubleFormat(bestAndDeep.LowPrice));
                printf("PreDelta: %.2f, ", DoubleFormat(bestAndDeep.PreDelta));
                printf("CurrDelta: %.2f, ", DoubleFormat(bestAndDeep.CurrDelta));

                printf("BuyPriceOne: %.2f, ", DoubleFormat(bestAndDeep.BuyPriceOne));
                printf("BuyQtyOne: %u, ", bestAndDeep.BuyQtyOne);
                printf("BuyImplyQtyOne: %u, ", bestAndDeep.BuyImplyQtyOne);
                printf("BuyPriceTwo: %.2f, ", DoubleFormat(bestAndDeep.BuyPriceTwo));
                printf("BuyQtyTwo: %u, ", bestAndDeep.BuyQtyTwo);
                printf("BuyImplyQtyTwo: %u, ", bestAndDeep.BuyImplyQtyTwo);
                printf("BuyPriceThree: %.2f, ", DoubleFormat(bestAndDeep.BuyPriceThree));
                printf("BuyQtyThree: %u, ", bestAndDeep.BuyQtyThree);
                printf("BuyImplyQtyThree: %u, ", bestAndDeep.BuyImplyQtyThree);
                printf("BuyPriceFour: %.2f, ", DoubleFormat(bestAndDeep.BuyPriceFour));
                printf("BuyQtyFour: %u, ", bestAndDeep.BuyQtyFour);
                printf("BuyImplyQtyFour: %u, ", bestAndDeep.BuyImplyQtyFour);
                printf("BuyPriceFive: %.2f, ", DoubleFormat(bestAndDeep.BuyPriceFive));
                printf("BuyQtyFive: %u, ", bestAndDeep.BuyQtyFive);
                printf("BuyImplyQtyFive: %u, ", bestAndDeep.BuyImplyQtyFive);

                printf("SellPriceOne: %.2f, ", DoubleFormat(bestAndDeep.SellPriceOne));
                printf("SellQtyOne: %u, ", bestAndDeep.SellQtyOne);
                printf("SellImplyQtyOne: %u, ", bestAndDeep.SellImplyQtyOne);
                printf("SellPriceTwo: %.2f, ", DoubleFormat(bestAndDeep.SellPriceTwo));
                printf("SellQtyTwo: %u, ", bestAndDeep.SellQtyTwo);
                printf("SellImplyQtyTwo: %u, ", bestAndDeep.SellImplyQtyTwo);
                printf("SellPriceThree: %.2f, ", DoubleFormat(bestAndDeep.SellPriceThree));
                printf("SellQtyThree: %u, ", bestAndDeep.SellQtyThree);
                printf("SellImplyQtyThree: %u, ", bestAndDeep.SellImplyQtyThree);
                printf("SellPriceFour: %.2f, ", DoubleFormat(bestAndDeep.SellPriceFour));
                printf("SellQtyFour: %u, ", bestAndDeep.SellQtyFour);
                printf("SellImplyQtyFour: %u, ", bestAndDeep.SellImplyQtyFour);
                printf("SellPriceFive: %.2f, ", DoubleFormat(bestAndDeep.SellPriceFive));
                printf("SellQtyFive: %u, ", bestAndDeep.SellQtyFive);
                printf("SellImplyQtyFive: %u, ", bestAndDeep.SellImplyQtyFive);

                printf("GenTime: %s, ", bestAndDeep.GenTime);
                printf("LastMatchQty: %u, ", bestAndDeep.LastMatchQty);
                printf("InterestChg: %d, ", bestAndDeep.InterestChg);
                printf("LifeLow: %.2f, ", DoubleFormat(bestAndDeep.LifeLow));
                printf("LifeHigh: %.2f, ", DoubleFormat(bestAndDeep.LifeHigh));
                printf("Delta: %.2f, ", DoubleFormat(bestAndDeep.Delta));
                printf("Gamma: %.2f, ", DoubleFormat(bestAndDeep.Gamma));
                printf("Rho: %.2f, ", DoubleFormat(bestAndDeep.Rho));
                printf("Theta: %.2f, ", DoubleFormat(bestAndDeep.Theta));
                printf("Vega: %.2f, ", DoubleFormat(bestAndDeep.Vega));
                printf("TradeDate: %s, ", bestAndDeep.TradeDate);
                printf("LocalDate: %s\n", bestAndDeep.LocalDate);
                break;
            case eArbi:
                struct MDBestAndDeep arbiBestAndDeep;
                fread(&arbiBestAndDeep, sizeof(struct MDBestAndDeep), 1, fp);
                printf("Type: %c, ", arbiBestAndDeep.Type);
                printf("Length: %u, ", arbiBestAndDeep.Length);
                printf("Version: %u, ", arbiBestAndDeep.Version);
                printf("Time: %u, ", arbiBestAndDeep.Time);
                printf("Exchange: %s, ", arbiBestAndDeep.Exchange);
                printf("Contract: %s, ", arbiBestAndDeep.Contract);
                printf("SuspensionSign: %d, ", arbiBestAndDeep.SuspensionSign);
                printf("LastClearPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.LastClearPrice));
                printf("ClearPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.ClearPrice));
                printf("AvgPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.AvgPrice));
                printf("LastClose: %.2f, ", DoubleFormat(arbiBestAndDeep.LastClose));
                printf("Close: %.2f, ", DoubleFormat(arbiBestAndDeep.Close));
                printf("OpenPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.OpenPrice));
                printf("LastOpenInterest: %u, ", arbiBestAndDeep.LastOpenInterest);
                printf("OpenInterest: %u, ", arbiBestAndDeep.OpenInterest);
                printf("LastPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.LastPrice));
                printf("MatchTotQty: %u, ", arbiBestAndDeep.MatchTotQty);
                printf("Turnover: %.2f, ", DoubleFormat(arbiBestAndDeep.Turnover));
                printf("RiseLimit: %.2f, ", DoubleFormat(arbiBestAndDeep.RiseLimit));
                printf("FallLimit: %.2f, ", DoubleFormat(arbiBestAndDeep.FallLimit));
                printf("HighPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.HighPrice));
                printf("LowPrice: %.2f, ", DoubleFormat(arbiBestAndDeep.LowPrice));
                printf("PreDelta: %.2f, ", DoubleFormat(arbiBestAndDeep.PreDelta));
                printf("CurrDelta: %.2f, ", DoubleFormat(arbiBestAndDeep.CurrDelta));

                printf("BuyPriceOne: %.2f, ", DoubleFormat(arbiBestAndDeep.BuyPriceOne));
                printf("BuyQtyOne: %u, ", arbiBestAndDeep.BuyQtyOne);
                printf("BuyImplyQtyOne: %u, ", arbiBestAndDeep.BuyImplyQtyOne);
                printf("BuyPriceTwo: %.2f, ", DoubleFormat(arbiBestAndDeep.BuyPriceTwo));
                printf("BuyQtyTwo: %u, ", arbiBestAndDeep.BuyQtyTwo);
                printf("BuyImplyQtyTwo: %u, ", arbiBestAndDeep.BuyImplyQtyTwo);
                printf("BuyPriceThree: %.2f, ", DoubleFormat(arbiBestAndDeep.BuyPriceThree));
                printf("BuyQtyThree: %u, ", arbiBestAndDeep.BuyQtyThree);
                printf("BuyImplyQtyThree: %u, ", arbiBestAndDeep.BuyImplyQtyThree);
                printf("BuyPriceFour: %.2f, ", DoubleFormat(arbiBestAndDeep.BuyPriceFour));
                printf("BuyQtyFour: %u, ", arbiBestAndDeep.BuyQtyFour);
                printf("BuyImplyQtyFour: %u, ", arbiBestAndDeep.BuyImplyQtyFour);
                printf("BuyPriceFive: %.2f, ", DoubleFormat(arbiBestAndDeep.BuyPriceFive));
                printf("BuyQtyFive: %u, ", arbiBestAndDeep.BuyQtyFive);
                printf("BuyImplyQtyFive: %u, ", arbiBestAndDeep.BuyImplyQtyFive);

                printf("SellPriceOne: %.2f, ", DoubleFormat(arbiBestAndDeep.SellPriceOne));
                printf("SellQtyOne: %u, ", arbiBestAndDeep.SellQtyOne);
                printf("SellImplyQtyOne: %u, ", arbiBestAndDeep.SellImplyQtyOne);
                printf("SellPriceTwo: %.2f, ", DoubleFormat(arbiBestAndDeep.SellPriceTwo));
                printf("SellQtyTwo: %u, ", arbiBestAndDeep.SellQtyTwo);
                printf("SellImplyQtyTwo: %u, ", arbiBestAndDeep.SellImplyQtyTwo);
                printf("SellPriceThree: %.2f, ", DoubleFormat(arbiBestAndDeep.SellPriceThree));
                printf("SellQtyThree: %u, ", arbiBestAndDeep.SellQtyThree);
                printf("SellImplyQtyThree: %u, ", arbiBestAndDeep.SellImplyQtyThree);
                printf("SellPriceFour: %.2f, ", DoubleFormat(arbiBestAndDeep.SellPriceFour));
                printf("SellQtyFour: %u, ", arbiBestAndDeep.SellQtyFour);
                printf("SellImplyQtyFour: %u, ", arbiBestAndDeep.SellImplyQtyFour);
                printf("SellPriceFive: %.2f, ", DoubleFormat(arbiBestAndDeep.SellPriceFive));
                printf("SellQtyFive: %u, ", arbiBestAndDeep.SellQtyFive);
                printf("SellImplyQtyFive: %u, ", arbiBestAndDeep.SellImplyQtyFive);

                printf("GenTime: %s, ", arbiBestAndDeep.GenTime);
                printf("LastMatchQty: %u, ", arbiBestAndDeep.LastMatchQty);
                printf("InterestChg: %d, ", arbiBestAndDeep.InterestChg);
                printf("LifeLow: %.2f, ", DoubleFormat(arbiBestAndDeep.LifeLow));
                printf("LifeHigh: %.2f, ", DoubleFormat(arbiBestAndDeep.LifeHigh));
                printf("Delta: %.2f, ", DoubleFormat(arbiBestAndDeep.Delta));
                printf("Gamma: %.2f, ", DoubleFormat(arbiBestAndDeep.Gamma));
                printf("Rho: %.2f, ", DoubleFormat(arbiBestAndDeep.Rho));
                printf("Theta: %.2f, ", DoubleFormat(arbiBestAndDeep.Theta));
                printf("Vega: %.2f, ", DoubleFormat(arbiBestAndDeep.Vega));
                printf("TradeDate: %s, ", arbiBestAndDeep.TradeDate);
                printf("LocalDate: %s\n", arbiBestAndDeep.LocalDate);
                break;
            case eMDTenEntrust:
                struct MDTenEntrust tenEntrust;
                fread(&tenEntrust, sizeof(struct MDTenEntrust), 1, fp);
                printf("Type: %c, ", tenEntrust.Type);
                printf("Len: %u, ", tenEntrust.Len);
                printf("Contract: %s, ", tenEntrust.Contract);
                printf("BestBuyOrderPrice: %.2f, ", DoubleFormat(tenEntrust.BestBuyOrderPrice));
                printf("BestBuyOrderQtyOne: %u, ", tenEntrust.BestBuyOrderQtyOne);
                printf("BestBuyOrderQtyTwo: %u, ", tenEntrust.BestBuyOrderQtyTwo);
                printf("BestBuyOrderQtyThree: %u, ", tenEntrust.BestBuyOrderQtyThree);
                printf("BestBuyOrderQtyFour: %u, ", tenEntrust.BestBuyOrderQtyFour);
                printf("BestBuyOrderQtyFive: %u, ", tenEntrust.BestBuyOrderQtyFive);
                printf("BestBuyOrderQtySix: %u, ", tenEntrust.BestBuyOrderQtySix);
                printf("BestBuyOrderQtySeven: %u, ", tenEntrust.BestBuyOrderQtySeven);
                printf("BestBuyOrderQtyEight: %u, ", tenEntrust.BestBuyOrderQtyEight);
                printf("BestBuyOrderQtyNine: %u, ", tenEntrust.BestBuyOrderQtyNine);
                printf("BestBuyOrderQtyTen: %u, ", tenEntrust.BestBuyOrderQtyTen);

                printf("BestSellOrderPrice: %.2f, ", DoubleFormat(tenEntrust.BestSellOrderPrice));
                printf("BestSellOrderQtyOne: %u, ", tenEntrust.BestSellOrderQtyOne);
                printf("BestSellOrderQtyTwo: %u, ", tenEntrust.BestSellOrderQtyTwo);
                printf("BestSellOrderQtyThree: %u, ", tenEntrust.BestSellOrderQtyThree);
                printf("BestSellOrderQtyFour: %u, ", tenEntrust.BestSellOrderQtyFour);
                printf("BestSellOrderQtyFive: %u, ", tenEntrust.BestSellOrderQtyFive);
                printf("BestSellOrderQtySix: %u, ", tenEntrust.BestSellOrderQtySix);
                printf("BestSellOrderQtySeven: %u, ", tenEntrust.BestSellOrderQtySeven);
                printf("BestSellOrderQtyEight: %u, ", tenEntrust.BestSellOrderQtyEight);
                printf("BestSellOrderQtyNine: %u, ", tenEntrust.BestSellOrderQtyNine);
                printf("BestSellOrderQtyTen: %u, ", tenEntrust.BestSellOrderQtyTen);
                printf("GenTime: %s\n", tenEntrust.GenTime);
                break;
            case eMDRealTimePrice:
                struct MDRealTimePrice realtimePrice;
                fread(&realtimePrice, sizeof(struct MDRealTimePrice), 1, fp);
                printf("Type: %c, ", realtimePrice.Type);
                printf("Len: %u, ", realtimePrice.Len);
                printf("ContractID: %s, ", realtimePrice.ContractID);
                printf("RealTimePrice: %.2f\n", DoubleFormat(realtimePrice.RealTimePrice));
                break;
            case eMDOrderStatistic:
                struct MDOrderStatistic orderStatistic;
                fread(&orderStatistic, sizeof(struct MDOrderStatistic), 1, fp);
                printf("MDOrderStatistic sizeof: %d, ", sizeof(struct MDOrderStatistic));
                printf("Type: %c, ", orderStatistic.Type);
                printf("Len: %u, ", orderStatistic.Len);
                printf("ContractID: %s, ", orderStatistic.ContractID);
                printf("TotalBuyOrderNum: %u, ", orderStatistic.TotalBuyOrderNum);
                printf("TotalSellOrderNum: %u, ", orderStatistic.TotalSellOrderNum);
                printf("WeightedAverageBuyOrderPrice: %.2f, ", DoubleFormat(orderStatistic.WeightedAverageBuyOrderPrice));
                printf("WeightedAverageSellOrderPrice: %.2f\n", DoubleFormat(orderStatistic.WeightedAverageSellOrderPrice));
                break;
            case eMDMarchPriceQty:
                struct MDMarchPriceQty marchPriceQty;
                fread(&marchPriceQty, sizeof(struct MDMarchPriceQty), 1, fp);
                printf("Type: %c, ", marchPriceQty.Type);
                printf("Len: %u, ", marchPriceQty.Len);
                printf("ContractID: %s, ", marchPriceQty.ContractID);
                printf("PriceOne: %.2f, ", DoubleFormat(marchPriceQty.PriceOne));
                printf("PriceOneBOQty: %u, ", marchPriceQty.PriceOneBOQty);
                printf("PriceOneBEQty: %u, ", marchPriceQty.PriceOneBEQty);
                printf("PriceOneSOQty: %u, ", marchPriceQty.PriceOneSOQty);
                printf("PriceOneSEQty: %u, ", marchPriceQty.PriceOneSEQty);
                printf("PriceTwo: %.2f, ", DoubleFormat(marchPriceQty.PriceTwo));
                printf("PriceTwoBOQty: %u, ", marchPriceQty.PriceTwoBOQty);
                printf("PriceTwoBEQty: %u, ", marchPriceQty.PriceTwoBEQty);
                printf("PriceTwoSOQty: %u, ", marchPriceQty.PriceTwoSOQty);
                printf("PriceTwoSEQty: %u, ", marchPriceQty.PriceTwoSEQty);
                printf("PriceThree: %.2f, ", DoubleFormat(marchPriceQty.PriceThree));
                printf("PriceThreeBOQty: %u, ", marchPriceQty.PriceThreeBOQty);
                printf("PriceThreeBEQty: %u, ", marchPriceQty.PriceThreeBEQty);
                printf("PriceThreeSOQty: %u, ", marchPriceQty.PriceThreeSOQty);
                printf("PriceThreeSEQty: %u, ", marchPriceQty.PriceThreeSEQty);
                printf("PriceFour: %.2f, ", DoubleFormat(marchPriceQty.PriceFour));
                printf("PriceFourBOQty: %u, ", marchPriceQty.PriceFourBOQty);
                printf("PriceFourBEQty: %u, ", marchPriceQty.PriceFourBEQty);
                printf("PriceFourSOQty: %u, ", marchPriceQty.PriceFourSOQty);
                printf("PriceFourSEQty: %u, ", marchPriceQty.PriceFourSEQty);
                printf("PriceFive: %.2f, ", DoubleFormat(marchPriceQty.PriceFive));
                printf("PriceFiveBOQty: %u, ", marchPriceQty.PriceFiveBOQty);
                printf("PriceFiveBEQty: %u, ", marchPriceQty.PriceFiveBEQty);
                printf("PriceFiveSOQty: %u, ", marchPriceQty.PriceFiveSOQty);
                printf("PriceFiveSEQty: %u\n", marchPriceQty.PriceFiveSEQty);
                break;
            default:
                printf("default, quote_style: %d\n", quote_style);
            }

        }
	}

	fclose(fp);
	return 0;
}
